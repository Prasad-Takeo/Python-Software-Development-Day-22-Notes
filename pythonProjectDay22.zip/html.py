"""
HTML

- Hyper Text Mark UP Language
- Not a Programming Language
- Markup Language for creating webpages/documents
- building blocks of the web

-- It does not need an server
- file must end with the .html extension
- Runs in a web browser
- index.html is the root/home page of the website

syntax
<tagname>content</tagname>

<h1>About Us</h1>
<p>This is a paragraph</p>
<br/>
<br>

Basic Tags
<!Doctype> defines the document type
<html> defines an HTML document
<head>
<title>
<body>
<h1> to <h6>
<p>
<br>
<hr>
<!--> - comment in html
"""

"""
python program to capture firstname, lastname
and age

and write it in a html file
file handling

a.html
b.html
c.html
"""

# firstname = input("enter the first name: ")
# lastname = input("enter the last name: ")
# age = input("enter the age: ")
# html_str = f"""
# <!DOCTYPE html>
# <html lang="en">
# <head>
#     <meta charset="UTF-8">
#     <title>Welcome Page</title>
# </head>
# <body>
# <picture>
# <img src="img.png">
# </picture>
# <h1>Welcome {firstname}, {lastname}</h1>
# <p>Your age is <mark><del>{age}</del></mark></p>
# </body>
# </html>
# """
# f =  open("welcome.html","w")
# f.write(html_str)
# f.close()

"""
Formatting Tags

<blockquote>
<abbr>
<cite> 
<b>
<i>
<em>
<strong>
<small>
<sub>
<sup>
<ins>
<del>
<mark>

Forms and Inputs
<form>
<input>
<output>
<textarea>
<button>
<select>
<option>
<label>

Images
<img>
<map>
<area>
<canvas>
<figure>
<figcaption>
<picture>
<svg>

Audio/Video
<audio>
<source>
<track>
<video>

Links
<a>
<link>
<nav>

HTML TABLES:
<table>
    <thead>
        <th></th>
    </thead>
    <tbody>
        <td></td>
    </tbody>
</table>
"""


"""
Write a program for creating the html table ( create html file ) from the python program
1. get data from https://worldweather.wmo.int/en/json/full_city_list.txt through requests module
    import requests
    data = requests.get("https://worldweather.wmo.int/en/json/full_city_list.txt")
    print(data.text)
2. create a html string with html table using python string datatype
3. write the html string to the html file
4. create your own css and link it with the html file created above.
"""
# import requests
#
# data= requests.get("https://worldweather.wmo.int/en/json/full_city_list.txt")
#
# new_data=data.text.split("\n")[:-2]
#
# table_string=""
# for items in new_data:
#     val=items.split("\n")
#
#     for i in val:
#         val=i.split(";")
#         print(val)
#         table_string+=f"<tr><td>{val[0] }</td><td>{val[1]}</td><td>{val[2]}</td></tr>"
#
# string_Html= f"""
# <!Doctype html>
# <html>
#     <head>
#     </head>
#     <body>
#         <table>
#         {table_string}
#         </table>
#     </body>
# </html>
# """
# f=open("tablehtml.html","w+")
# f.write(string_Html)
# f.close()

"""
Stock Buy Sell to maximize profit
{100,180,260,310,40,535,900}
find the max profit that you can make by buying and selling in the above said days
(310-100) + (900-40) = 1070
"""

"""
profit = 0
day 0 -> no profit
day 1 < day 0 => 180 - 100 = 80
day 2 < day 1 => 260 - 180 = 80 + (80) = 160
day 3 < day 2 => 310 - 260 = 50 + (160) = 210
day 4 < day 3 =>
day 5 < day 4 => 535 - 40  = 495 + (210) = 705
day 6 < day 5 => 900 - 535 = 365 + (705) = 1070

"""

stock_prices = [100,180,260,310,40,535,900]
profit = 0
for i in range(1,len(stock_prices)):
    if stock_prices[i] > stock_prices[i-1]:
        profit = profit + (stock_prices[i]-stock_prices[i-1])
print(profit)