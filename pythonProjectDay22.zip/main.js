var name = "sugumar";
var lastname = "V";
alert("HI!, " + name + " " + lastname + ". This is an alert box coming from main.js");
console.log("Hey! this is the JS fundementals tutorial")


var sampleArray = [112,232,2399,87239,829371];
document.write(sampleArray[0]+"<br>");

//array methods
//reverse
sampleArray.reverse()
document.write("Reversed array is " + sampleArray + "<br>")


//join
var newArray =  sampleArray.join("-")
console.log(newArray)

//sort
document.write(sampleArray.sort() + "<br>");

//numbers
var n1 = 22;
var n2 = 44;
document.write(n1+n2+"<br>");

var n3 = "55"
document.write(n1+n2+Number(n3)+"<br>");

var n1=22, n2=33, n3=11, n4=55.09;
document.write("Round of "+n4+" is " + Math.round(n4) +"<br>");
//math.min, math.max, math.sqrt, math.log

//strings
var sampleString = "Hesaid \"Hello world\" when he woke up"
//                 01234567
//document.write(sampleString + "<br>")
//sampleString.length
//sampleString.toUpperCase()
//sampleString.toLowerCase()
//sampleString.split(" ")
document.write("Index of world: "+sampleString.indexOf("world") + '<br>')
//slicing
document.write("Sliced String is: " + sampleString.slice(0,8)); //

//dates
var currrentDT = new Date()
document.write("<br>" + "The current date and time is : " + currrentDT);

var anotherDate = new Date(2020,03,16,13,04,26);
document.write("<br>" + anotherDate);

//getMonth();
//getFullYear();
//getYear(); deprecated
//getDate();
//getHours();
//getTime();

var student1 = {
    name:"Daniel",
    class: "A",
    roll_no: 22
}

document.write("Name: "+ student1.name);
document.write("Class: "+ student1.class);
document.write("Roll No: "+ student1.roll_no);

var student2 = {
    name: "Eric",
    class: "B",
    roll_no: 45
}

function studentDetails() {
    document.write("<br>Student Name:" + this.name + ", <br>Class:" + this.class + "<br>Roll No:" + this.roll_no);
}

student1.logDetails = studentDetails;
student2.logDetails = studentDetails;



student1.logDetails();
student2.logDetails();

student3 = {
    name: "Sugumar",
    class: "A",
    roll_no: 97
}
student3.printdata = studentDetails
student3.printdata()

//conditioning
if (condition) {
    if (condition) {
    //code
    } else if (condition) {
    //code
    } else {
    //code
    }
} else if (condition) {
    //code
} else {
    //code
}

//Operators: +,-,/,*,%
// =, +=, -=, *=, /=
// ==, !=, ===, !==, >, <, >=, <=

// num4 =8; num1= 4
// num4/2 !== num1
// num4/2 === num1
// === check for equal value and equal type

//++,--
//num5 = 5; ++num5, num5++

// a > b ? a : b
// 2 > 3 ? 2 : 3

//while (condition) {
// code
// }

//do {
//
//} while (condition);

for(i=0, i<=10, i++) {
}
//continue
//break

//function <funcname> {
// //local variable
//}

//global variable