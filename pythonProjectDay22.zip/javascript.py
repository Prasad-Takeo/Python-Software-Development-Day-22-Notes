"""
JS - Javascript

Js is a simple, light -weight, object-oriented browser based programming language
that runs on any of the latest browsers

It isn't IDE dependent and one can code in any basic code editor.

Dynamic interactivity on websistes is enabled when JS is used with HTML

JS is case sensitive (name and NAME is different)
semi-colon as a delimiter

To add/enable Js file to the HTML, we use th
<script> tag,

JS line of code can be placed in the <head> section as well.
The best practice is to put the JS <script> tags at the end of the <body>

Variables

var name = "sugumar";
var lastname = "v"

Variable names cannot begin with a number nor have space in between the letters

var weekly sales #invalid variable name, either it should be weekly_sales or weeklySales

Arrays - hold multiple values

var sampleArray = [112,23,239,890,8283]

"""